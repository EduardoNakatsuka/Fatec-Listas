Procedimento: Procedimentos s�o estruturas que agrupam um conjunto
de comandos, que s�o executados quando o procedimento � chamado.

fun��o: Uma fun��o nada mais � do que uma subrotina usada em um programa. Na linguagem C, denominamos fun��o a um conjunto de comandos que realiza uma tarefa espec�fica em um m�dulo dependente de c�digo. A fun��o � referenciada pelo programa principal atrav�s do nome atribu�do a ela.